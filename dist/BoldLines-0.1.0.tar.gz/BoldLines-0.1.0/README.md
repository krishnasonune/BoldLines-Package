
# BoldLines Package

BoldLines package will help you to impress other people by using unique pickup lines

## Installation

Install BoldLine package using command

```bash
  pip install BoldLines
```
    
## Examples

```python
    from BoldLines import lines

    fun = lines.getLine(type='funny')
    print(fun)

    chessy = lines.getLine(type='cheesy')
    print(chessy)

    cute = lines.getLine(type='cute')
    print(cute)
```


## Authors

- [@krishna sonune](https://www.github.com/krishnasonune)


## 👨‍💻 About Me
I'm a full stack developer...

